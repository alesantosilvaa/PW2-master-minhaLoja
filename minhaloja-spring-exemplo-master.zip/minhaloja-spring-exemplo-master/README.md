# minhaloja-spring-exemplo
Loja Virtual usado como exemplo para disciplina PWeb2
# a-loja

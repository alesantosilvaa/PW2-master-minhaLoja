package com.example.minhaloja.repositorios;

import com.example.minhaloja.modelo.Pedido;

import org.springframework.data.repository.CrudRepository;

public interface RepositorioPedido extends CrudRepository<Pedido, Long>{
    
}
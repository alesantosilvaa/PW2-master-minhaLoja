package com.example.minhaloja.controle;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class Controlador{
    @RequestMapping("/")
    public ModelAndView index(){
        ModelAndView retorno = new ModelAndView("index.html");
        return retorno;
    }
}